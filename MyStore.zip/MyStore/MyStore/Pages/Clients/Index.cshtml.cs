using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients


{
    public class IndexModel : PageModel
    {
        public List<ClientInfo> listClients = new List<ClientInfo>();

        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-MJQF0IH;Initial Catalog=testdb;Integrated Security=True";
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string sql = "select * from cliens";
                        using (SqlCommand Command = new SqlCommand(sql, connection))
                        {
                            using (SqlDataReader reader = Command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    ClientInfo client = new ClientInfo();
                                    ClientInfo.ID = "" + reader.GetInt32(0);
                                    ClientInfo.Name = reader.GetString(1);
                                    ClientInfo.email = reader.GetString(2);
                                    ClientInfo.phone = reader.GetString(3);
                                    ClientInfo.address = reader.GetString(4);
                                    ClientInfo.created_at = reader.GetDateTime(5).ToString();
                                    listClients.Add(ClientInfo);

                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }

    public class ClientInfo
    {
        public string ID;
        public string Name;
        public string email;
        public string phone;
        public string address;

    }   
}

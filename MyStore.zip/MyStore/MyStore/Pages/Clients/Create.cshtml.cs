using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients
{
    public class CreateModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        public string errorMessage = "";
        public string successMessage = "";


        public void OnGet(ClientInfo clientInfo)
        {
			clientInfo.Name = Request.Form["name"];
			clientInfo.email = Request.Form["email"];
			clientInfo.phone = Request.Form["phone"];
			clientInfo.address = Request.Form["address"];

            if (clientInfo.Name.Length == 0 || clientInfo.email.Length == 0 || clientInfo.phone.Length == 0 || clientInfo.address.Length)
            {
                errorMessage = "all the fields are required";
                return;
            }

            try
            {
                string connectionString = "Data Source=DESKTOP-MJQF0IH;Initial Catalog=testdb;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "insert into clients" +
                        "(name, email, phone, address) values " +
                        "(@name, @email, @phone, @address)";

                    using (SqlCommand Command = new SqlCommand(sql, connection))
                    {

                        Command.Parameters.AddWithValue("@name", clientInfo.Name);
                        Command.Parameters.AddWithValue("@email", clientInfo.email);
                        Command.Parameters.AddWithValue("@phone", clientInfo.phone);
                        Command.Parameters.AddWithValue("@address", clientInfo.address);

                        Command.ExecuteNonQuery();
                    }


                }


            }
            catch
            {

            }


			clientInfo.Name = "";
			clientInfo.email = "";
			clientInfo.phone = ""; 
            clientInfo.address = "";
			successMessage = "new client added correctly";

      
            Response.Redirect("/Clients/Index");

 
		}
    }
}

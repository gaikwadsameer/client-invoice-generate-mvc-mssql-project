using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients
{
    public class EditModel : PageModel
    {

		public ClientInfo clientInfo = new ClientInfo();
		public string errorMessage = "";
		public string successMessage = "";

		public void OnGet()
        {

            string id = Request.Query["id"];

            try
            {
				string connectionString = "Data Source=DESKTOP-MJQF0IH;Initial Catalog=testdb;Integrated Security=True";
				{
					using (SqlConnection connection = new SqlConnection(connectionString))
					{
						connection.Open();
						string sql = "update cliens" + "set name=@name, email=@email, phone=@phone, address=@address" + 
							"where ID=@ID";
						using (SqlCommand Command = new SqlCommand(sql, connection))
						{
							using (SqlDataReader reader = Command.ExecuteReader())
							{
								while (reader.Read())
								{
									ClientInfo client = new ClientInfo();
									ClientInfo.ID = "" + reader.GetInt32(0);
									ClientInfo.Name = reader.GetString(1);
									ClientInfo.email = reader.GetString(2);
									ClientInfo.phone = reader.GetString(3);
									ClientInfo.address = reader.GetString(4);
										

								}
							}
						}
					}
				}

			}


            catch (Exception ex)
            {

                errorMessage = ex.Message;
            }
			

			Public void OnPost()
			{

				clientInfo.Name = Request.Form["name"];
				clientInfo.email = Request.Form["email"];
				clientInfo.phone = Request.Form["phone"];
				clientInfo.address = Request.Form["address"];

				if (clientInfo.Name.Length == 0 || clientInfo.email.Length == 0 || clientInfo.phone.Length == 0 || clientInfo.address.Length)
				{
					errorMessage = "all the fields are required";
					return;
				}

			}

			Response.Redirect("/clients/index");

		}
    }
}
